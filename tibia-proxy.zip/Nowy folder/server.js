import express from "express";
import { chromium } from "playwright";

const app = express();
const PORT = process.env.PORT || 3000;

app.get("/guild", async (req, res) => {
    const guild = req.query.name || "Sleepers";
    const url = `https://www.tibia.com/community/?subtopic=guilds&page=view&GuildName=${encodeURIComponent(guild)}`;

    try {
        const browser = await chromium.launch({
            args: ["--no-sandbox", "--disable-setuid-sandbox"]
        });
        const page = await browser.newPage();

        await page.goto(url, { waitUntil: "domcontentloaded" });

        const html = await page.content();
        await browser.close();

        const regex = /\?subtopic=characters&amp;name=([^"]+)">([^<]+)<\/a>/g;
        const members = [];
        let match;

        while ((match = regex.exec(html)) !== null) {
            members.push({ name: match[2] });
        }

        res.json({
            guild,
            members
        });

    } catch (err) {
        res.json({ error: "Proxy error", details: err.toString() });
    }
});

app.listen(PORT, () => {
    console.log(`Proxy running on port ${PORT}`);
});
